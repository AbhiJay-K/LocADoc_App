package com.locadoc_app.locadoc.UI.Login;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.locadoc_app.locadoc.Cognito.AppHelper;
import com.locadoc_app.locadoc.Cognito.CognitoSyncClientManager;
import com.locadoc_app.locadoc.R;
import com.locadoc_app.locadoc.UI.ConfirmSignUp.Activity_SignUp_Confirm;
import com.locadoc_app.locadoc.UI.NewPassword.NewPasswordActivity;
import com.locadoc_app.locadoc.UI.Signup.SignUp;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.OnFocusChange;

public class LoginActivity extends AppCompatActivity implements LoginViewInterface
{
    private LoginPresenterInterface loginPres;
    private ProgressDialog waitDialog;
    private AlertDialog userDialog;
    CallbackManager callbackManager;
    @BindView(R.id.UserID)
    AutoCompleteTextView userIDView;
    @BindView(R.id.Password)
    EditText passView;
    LoginButton btnLoginFacebook;

    private ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        callbackManager = CallbackManager.Factory.create();
        FacebookSdk.sdkInitialize(getApplicationContext());
        //AppEventsLogger.activateApp(this);
        loginPres = new LoginPresenter(this);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        AppHelper.init(getApplicationContext());
        CognitoSyncClientManager.init(this);
        // wipe data
        Log.d("facebook token", "Test");
        // start Facebook Login
        btnLoginFacebook = (LoginButton) findViewById(R.id.FacebookButton);
        //If access token is already here, set fb session
        final AccessToken fbAccessToken = AccessToken.getCurrentAccessToken();
        if (fbAccessToken != null) {
            LoginManager.getInstance().logOut();
            //loginPres.setFacebookSession(fbAccessToken);

            //btnLoginFacebook.setVisibility(View.GONE);
        }
        btnLoginFacebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginManager.getInstance().logInWithReadPermissions(LoginActivity.this, Arrays.asList("public_profile"));
                LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        btnLoginFacebook.setVisibility(View.GONE);
                        Log.d("facebook token", "Success");
                        new GetFbName(loginResult).execute();
                        loginPres.setFacebookSession(loginResult.getAccessToken());
                    }

                    @Override
                    public void onCancel() {
                        Log.d("facebook token", "Cancel");
                        Toast.makeText(LoginActivity.this, "Facebook login cancelled",
                                Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onError(FacebookException error) {
                        Log.d("facebook token", "Fail");
                        Toast.makeText(LoginActivity.this, "Error in Facebook login " +
                                error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
        btnLoginFacebook.setEnabled(getString(R.string.facebook_app_id) != "facebook_app_id");
        CognitoSyncClientManager.getInstance()
                .wipeData();
        AppHelper.getPool().getCurrentUser().signOut();
    }
    private class GetFbName extends AsyncTask<Void, Void, String> {
        private final LoginResult loginResult;

        public GetFbName(LoginResult loginResult) {
            this.loginResult = loginResult;
        }
        @Override
        protected void onPreExecute() {
            dialog = ProgressDialog.show(LoginActivity.this, "Wait", "Getting user name");
        }
        @Override
        protected String doInBackground(Void... params) {
            GraphRequest request = GraphRequest.newMeRequest(
                    loginResult.getAccessToken(),
                    new GraphRequest.GraphJSONObjectCallback() {
                        @Override
                        public void onCompleted(
                                JSONObject object,
                                GraphResponse response) {
                            // Application code
                            Log.d("LoginActivity facebook ", response.toString());
                        }
                    });
            Bundle parameters = new Bundle();
            parameters.putString("fields", "name");
            request.setParameters(parameters);
            GraphResponse graphResponse = request.executeAndWait();
            try {
                return graphResponse.getJSONObject().getString("name");
            } catch (JSONException e) {
                return null;
            }
        }
        @Override
        protected void onPostExecute(String response) {
            dialog.dismiss();
            if (response != null) {
                Toast.makeText(LoginActivity.this, "Hello " + response, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(LoginActivity.this, "Unable to get user name from Facebook",
                        Toast.LENGTH_LONG).show();
            }
        }

    }

    @OnClick (R.id.SignupButton)
    void onSignupClick(View v)
    {
        Log.d("LocAdoc", "Sign up");
        Intent signUp = new Intent(this, SignUp.class);
        startActivityForResult(signUp, 1);
    }

    @OnClick (R.id.LoginButton)
    void onLoginClick(View v)
    {
        loginPres.onLoginClick(userIDView.getText().toString(),
                                passView.getText().toString());
    }

    /*@OnClick (R.id.FacebookButton)
    void onFacebookLoginClick(View v)
    {
        loginPres.onFacebookLoginClick(callbackManager,this);
    }*/



    /*@OnClick (R.id.GoogleButton)
    void onGoogleLoginClick(View v)
    {
        loginPres.onGoogleLoginClick();
    }*/

    @OnClick (R.id.ForgotPasswordText)
    void onForgotPasswordClick(View v)
    {
        loginPres.onForgotPasswordClick();
    }

    @OnFocusChange (R.id.UserID)
    void onChangeID (View v)
    {
        userIDView.setError(null);
        loginPres.onChangeID(userIDView.getText().toString());
    }

    @OnFocusChange (R.id.Password)
    void onChangePassword (View v)
    {
        passView.setError(null);
        loginPres.onChangePassword(passView.getText().toString());
    }

    @Override
    public void setIDError(String message) { userIDView.setError(message);}

    @Override
    public void setPassError(String message) { passView.setError(message);}

    @Override
    public void openMainActivity()
    {

    }

    public void openForgotPasswordActivity() {
        Log.d("LocAdoc", "Open Forgot Password Activity");
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK)
        {
            switch (requestCode) {
                case 1:
                    String name = data.getStringExtra("name");
                    if (!name.isEmpty()) {
                        userIDView.setText(name);
                        passView.setText("");
                        passView.requestFocus();
                    }
                    String userPasswd = data.getStringExtra("password");
                    if (!userPasswd.isEmpty()) {
                        passView.setText(userPasswd);
                    }
                    if (!name.isEmpty() && !userPasswd.isEmpty()) {
                        // We have the user details, so sign in!
                        loginPres.onLoginClick(name, userPasswd);
                    }
                    break;
                case 2:
                    loginPres.onLoginClick(userIDView.getText().toString(),
                            passView.getText().toString());
                    break;
                case 6:
                    //New password
                    closeWaitDialog();
                    Boolean continueSignIn = data.getBooleanExtra("continueSignIn", false);
                    if (continueSignIn) {
                        loginPres.continueWithFirstTimeSignIn();
                    }
            }

        }

    }

    public void confirmUser() {
        Intent confirmActivity = new Intent(this, Activity_SignUp_Confirm.class);
        confirmActivity.putExtra("name", userIDView.getText().toString());
        startActivityForResult(confirmActivity, 2);
    }

    public void firstTimeSignIn() {
        Intent newPasswordActivity = new Intent(this, NewPasswordActivity.class);
        newPasswordActivity.putExtra("user name", userIDView.getText().toString());
        startActivityForResult(newPasswordActivity, 6);
    }

    public AutoCompleteTextView getUserIDView()
    {
        return userIDView;
    }

    public EditText getPassView()
    {
        return passView;
    }

    public void showWaitDialog(String message) {
        closeWaitDialog();
        waitDialog = new ProgressDialog(this);
        waitDialog.setTitle(message);
        waitDialog.show();
    }

    public void showDialogMessage(String title, String body) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title).setMessage(body).setNeutralButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                try {
                    userDialog.dismiss();
                } catch (Exception e) {
                    //
                }
            }
        });
        userDialog = builder.create();
        userDialog.show();
    }
    public void setFbBottonVisibilityGone()
    {
        btnLoginFacebook.setVisibility(View.GONE);
    }
    public void SetFBBtn()
    {
        btnLoginFacebook.setEnabled(getString(R.string.facebook_app_id) != "facebook_app_id");
    }
    public void onPreExecute() {
        dialog = ProgressDialog.show(this, "Wait", "Getting user name");
    }

    public void onPostExecute(String response) {
        dialog.dismiss();
        if (response != null) {
            showDialogMessage("Facebook login", "Hello " + response);
        } else {
            showDialogMessage("Facebook login", "Unable to get user name from Facebook");
        }
    }
    public void closeWaitDialog() {
        try {
            waitDialog.dismiss();
        }
        catch (Exception e) {
            //
        }
    }
}
