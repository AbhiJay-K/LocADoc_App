package com.locadoc_app.locadoc.UI.Login;

import com.facebook.AccessToken;

/**
 * Created by Admin on 9/12/2017.
 */

public interface LoginPresenterInterface {
    void onLoginClick(String id, String password);
    void onGoogleLoginClick();
    //void onFacebookLoginClick(CallbackManager callbackManager,LoginActivity login);
    void onForgotPasswordClick();
    boolean onChangeID(String id);
    boolean onChangePassword(String pass);
    void continueWithFirstTimeSignIn();
    void setFacebookSession(AccessToken accessToken);
}
