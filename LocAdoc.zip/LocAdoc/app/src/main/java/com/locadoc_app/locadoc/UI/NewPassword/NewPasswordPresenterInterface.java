package com.locadoc_app.locadoc.UI.NewPassword;

/**
 * Created by Admin on 9/15/2017.
 */

public interface NewPasswordPresenterInterface {
}
